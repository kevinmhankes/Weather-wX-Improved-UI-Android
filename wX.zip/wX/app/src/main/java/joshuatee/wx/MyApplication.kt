/*

    Copyright 2013, 2014, 2015, 2016, 2017, 2018  joshua.tee@gmail.com

    This file is part of wX.

    wX is free software: you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation, either version 3 of the License, or
    (at your option) any later version.

    wX is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with wX.  If not, see <http://www.gnu.org/licenses/>.

*/

package joshuatee.wx

import android.app.Application
import android.content.ContentResolver
import android.content.Context
import android.content.SharedPreferences
import android.content.res.Resources
import android.graphics.Color
import android.preference.PreferenceManager
import android.provider.Settings
import android.util.DisplayMetrics
import android.util.TypedValue

import java.util.concurrent.TimeUnit
import java.util.regex.Pattern

import joshuatee.wx.audio.UtilityTTS
import joshuatee.wx.notifications.UtilityNotificationTextProduct
import joshuatee.wx.objects.GeographyType
import joshuatee.wx.radarcolorpalettes.ObjectColorPalette
import joshuatee.wx.settings.Location
import joshuatee.wx.settings.UtilityHomeScreen
import joshuatee.wx.util.UtilityCities
import joshuatee.wx.util.UtilityLog
import okhttp3.Interceptor
import okhttp3.OkHttpClient
import java.io.BufferedInputStream
import java.io.DataInputStream
import java.io.IOException
import java.nio.ByteBuffer
import java.nio.ByteOrder

class MyApplication : Application() {

    // This is called when the overall system is running low on memory,
    // and would like actively running processes to tighten their belts.
    // Overriding this method is totally optional!
    override fun onLowMemory() {
        //super.onLowMemory()
    }

    override fun onCreate() {
        super.onCreate()
        preferences = PreferenceManager.getDefaultSharedPreferences(this)
        editor = preferences.edit()
        preferencesTelecine = getSharedPreferences("telecine", Context.MODE_PRIVATE)
        contentResolverLocal = contentResolver
        comma = Pattern.compile(",")
        bang = Pattern.compile("!")
        space = Pattern.compile(" ")
        colon = Pattern.compile(":")
        colonSpace = Pattern.compile(": ")
        semicolon = Pattern.compile(";")
        period = Pattern.compile("\\.")
        slash = Pattern.compile("/")
        val res = resources
        dm = res.displayMetrics
        deviceScale = TypedValue.applyDimension(TypedValue.COMPLEX_UNIT_DIP, 1f, dm)
        padding = TypedValue.applyDimension(TypedValue.COMPLEX_UNIT_DIP, res.getDimension(R.dimen.padding_dynamic_tv), dm).toInt()
        paddingSmall = TypedValue.applyDimension(TypedValue.COMPLEX_UNIT_DIP, res.getDimension(R.dimen.padding_dynamic_tv_small), dm).toInt()
        textSizeSmall = res.getDimension(R.dimen.listitem_text)
        textSizeNormal = res.getDimension(R.dimen.normal_text)
        textSizeLarge = res.getDimension(R.dimen.large_text)
        lLpadding = res.getDimension(R.dimen.padding_ll)
        // Calculate ActionBar height
        val tv = TypedValue()
        if (theme.resolveAttribute(android.R.attr.actionBarSize, tv, true)) { actionBarHeight = TypedValue.complexToDimensionPixelSize(tv.data, res.displayMetrics) }
        initPreferences(this)
        primaryColor = preferences.getInt("MYAPP_PRIMARY_COLOR", 0)
        Location.refreshLocationData(this)
        System.setProperty("http.keepAlive", "false")
        newline = System.getProperty("line.separator")
        spinnerLayout = if (UIPreferences.themeInt == R.style.MyCustomTheme_white_NOAB) {
            R.layout.spinner_row_white
        } else {
            R.layout.spinner_row_blue
        }
        val okhttp3Interceptor = Interceptor { chain ->
            val request = chain.request()
            var response = chain.proceed(request)
            var tryCount = 0
            while (!response.isSuccessful && tryCount < 3) {
                tryCount+=1
                response = chain.proceed(request)
            }
            response
        }
        httpClient = OkHttpClient.Builder()
                .connectTimeout(15, TimeUnit.SECONDS)
                .readTimeout(15, TimeUnit.SECONDS)
                .addInterceptor(okhttp3Interceptor)
                .build()
        UtilityTTS.initTTS(applicationContext)
        UtilityCities.initCitiesArray()
        if (!loadedBuffers) {initBuffers(this)}
    }

    companion object {
        const val nwsSPCwebsitePrefix = "https://www.spc.noaa.gov"
        const val nwsWPCwebsitePrefix = "https://www.wpc.ncep.noaa.gov"
        const val prefSeperator = " : : :"
        var uiAnimIconFrames = "rid"
        // FIXME remove in favor of notificationStrSep
        //const val NOTIF_STR_SEP = ","
        const val WIDGET_FILE_BAK = "BAK"
        val HM_CLASS = mutableMapOf<String, Class<*>>()
        val HM_CLASS_ARGS = mutableMapOf<String, Array<String>>()
        val HM_CLASS_ID = mutableMapOf<String, String>()
        init {UtilityHomeScreen.setupMap()}
        var primaryColor: Int = 0
        const val TEXTVIEW_MAGIC_FUDGE_FACTOR = 4.05f
        var deviceScale = 0.toFloat()
        var httpClient: OkHttpClient? = null
        // FIXME make private

        lateinit var preferences: SharedPreferences
        //private lateinit var preferences: SharedPreferences

        private lateinit var preferencesTelecine: SharedPreferences

        //private lateinit var editor: SharedPreferences.Editor
        lateinit var editor: SharedPreferences.Editor

        lateinit var dm: DisplayMetrics


        var mediaNotifTtsTitle = ""
        const val notificationStrSep = ","
        var cardElevation = 0.toFloat()
        var fabElevation = 0.toFloat()
        var fabElevationDepressed = 0.toFloat()
        var elevationPref = 0.toFloat()
        var textSizeSmall = 0.toFloat()
        var textSizeNormal = 0.toFloat()
        var textSizeLarge = 0.toFloat()
        var cardCorners = 0.toFloat()
        var lLpadding = 0.toFloat()
        var telecineVideoSizePercentage = 0
        var telecineSwitchShowCountdown = false
        var telecineSwitchRecordingNotification = false
        var telecineSwitchShowTouches = false
        var tileDownsize = false
        var iconsEvenSpaced = false
        var helpMode = false
        var simpleMode = false
        var checkspc = false
        var checkwpc = false
        var checktor = false
        var vrButton = false
        var radarUseJni = false
        var contentResolverLocal: ContentResolver? = null
        var blackBg = false
        var fullscreenMode = false
        var lockToolbars = false
        var unitsM = false
        var unitsF = false
        var locDisplayImg = false
        var comma: Pattern = Pattern.compile("")
        var bang: Pattern = Pattern.compile("")
        var alertOnlyonce = false
        var drawToolColor = 0
        var widgetTextColor = 0
        var widgetHighlightTextColor = 0
        var widgetNexradSize = 0
        var widgetCCShow7Day = false
        var nwsIconTextColor = 0
        var nwsIconBottomColor = 0
        var nexradRadarBackgroundColor = 0
        var wxoglSize = 0
        var wxoglRememberLocation = false
        var wxoglRadarAutorefresh = false
        var wfoFav = ""
        var ridFav = ""
        var sndFav = ""
        var srefFav = ""
        var spcmesoFav = ""
        var spcmesoLabelFav = ""
        var nwsTextFav = ""
        var radarColorPalette = mutableMapOf<String, String>()
        var notifSoundUri = ""
        var homescreenFav = ""
        const val HOMESCREEN_FAV_DEFAULT = "TXT-CC2:TXT-HAZ:OGL-RADAR:TXT-7DAY2"
        const val HOMESCREEN_FAV_DEFAULT_CA = "TXT-CC2:TXT-HAZ:IMG-CARAIN:TXT-7DAY2"
        var alertNotificationSoundTornadoCurrent = false
        var alertNotificationSoundSpcmcd = false
        var alertNotificationSoundWpcmpd = false
        var alertNotificationSoundNhcEpac = false
        var alertNotificationSoundNhcAtl = false
        var alertNotificationSoundSpcwat = false
        var alertNotificationSoundSpcswo = false
        var alertNotificationSoundTextProd = false
        var notifSoundRepeat = false
        var notifTts = false
        var alertBlackoutAmCurrent = 0
        var alertBlackoutPmCurrent = 0
        var alertTornadoNotificationCurrent = false
        var alertSpcmcdNotificationCurrent = false
        var alertSpcwatNotificationCurrent = false
        var alertSpcswoNotificationCurrent = false
        var alertSpcswoSlightNotificationCurrent = false
        var alertWpcmpdNotificationCurrent = false
        var alertBlackoutTornadoCurrent = false
        var alertNhcEpacNotificationCurrent = false
        var alertNhcAtlNotificationCurrent = false
        var alertAutocancel = false
        var alertBlackout = false
        const val DEGREE_SYMBOL = "\u00B0"
        var playlistStr = ""
        var notifTextProdStr = ""
        var radarColorPalette94List = ""
        var radarColorPalette99List = ""
        var newline = ""
        var space: Pattern = Pattern.compile("")
        var colon: Pattern = Pattern.compile("")
        var colonSpace: Pattern = Pattern.compile("")
        var semicolon: Pattern = Pattern.compile("")
        var period: Pattern = Pattern.compile("")
        var slash: Pattern = Pattern.compile("")
        var spinnerLayout = R.layout.spinner_row_blue
        var actionBarHeight = 0
        var wxoglZoom = 0.toFloat()
        var wxoglRid = ""
        var wxoglProd = ""
        var wxoglX = 0.toFloat()
        var wxoglY = 0.toFloat()
        val severeDashboardTor = DataStorage("SEVERE_DASHBOARD_TOR")
        val severeDashboardTst = DataStorage("SEVERE_DASHBOARD_TST")
        val severeDashboardFfw = DataStorage("SEVERE_DASHBOARD_FFW")
        val severeDashboardWat = DataStorage("SEVERE_DASHBOARD_WAT")
        val severeDashboardMcd = DataStorage("SEVERE_DASHBOARD_MCD")
        val severeDashboardMpd = DataStorage("SEVERE_DASHBOARD_MPD")
        val watchLatlon = DataStorage("WATCH_LATLON")
        val watchLatlonTor = DataStorage("WATCH_LATLON_TOR")
        val mcdLatlon = DataStorage("MCD_LATLON")
        val mcdNoList = DataStorage("MCD_NO_LIST")
        val mpdLatlon = DataStorage("MPD_LATLON")
        val mpdNoList = DataStorage("MPD_NO_LIST")
        var wfoTextFav = ""
        var wpcTextFav = ""
        var spotterFav = ""
        const val ICON_ALERT_2 = R.drawable.ic_report_24dp
        const val ICON_MAP = R.drawable.ic_public_24dp
        const val ICON_MPD = R.drawable.ic_brightness_7_24dp
        const val ICON_TORNADO = R.drawable.ic_flash_off_24dp
        const val ICON_MCD = R.drawable.ic_directions_24dp
        const val ICON_ACTION = R.drawable.ic_play_arrow_24dp
        const val ICON_ALERT = R.drawable.ic_warning_24dp
        const val ICON_RADAR = R.drawable.ic_flash_on_24dp
        const val ICON_FORECAST = R.drawable.ic_place_24dp
        const val ICON_CURRENT = R.drawable.ic_info_outline_24dp
        const val ICON_NHC_1 = R.drawable.ic_brightness_auto_24dp
        const val ICON_NHC_2 = R.drawable.ic_brightness_medium_24dp
        const val ICON_DELETE = R.drawable.ic_delete_24dp
        const val STAR_ICON = R.drawable.ic_star_24dp
        const val STAR_OUTLINE_ICON = R.drawable.ic_star_outline_24dp
        const val ICON_PLAY = R.drawable.ic_play_arrow_24dp
        const val ICON_STOP = R.drawable.ic_stop_24dp
        const val ICON_MIC = R.drawable.ic_mic_24dp
        const val ICON_PAUSE = R.drawable.ic_pause_24dp
        const val ICON_PAUSE_PRESSED = R.drawable.ic_pause_white_24dp
        const val ICON_ARROW_UP = R.drawable.ic_keyboard_arrow_up_24dp
        const val ICON_ARROW_DOWN = R.drawable.ic_keyboard_arrow_down_24dp
        const val ICON_ADD = R.drawable.ic_add_box_24dp
        const val ICON_BACK = R.drawable.ic_keyboard_arrow_left_24dp
        const val ICON_FORWARD = R.drawable.ic_keyboard_arrow_right_24dp
        const val ICON_SKIP_BACK = R.drawable.ic_skip_previous_24dp
        const val ICON_SKIP_FORWARD = R.drawable.ic_skip_next_24dp
        const val MD_COMP = "<center>No Mesoscale Discussions are currently in effect."
        const val WATCH_COMP = "<center><strong>No watches are currently valid"
        const val MPD_COMP = "No MPDs are currently in effect."
        const val currentConditionsViaMetar = true
        var spchrrrZoom = 0.toFloat()
        var spchrrrX = 0.toFloat()
        var spchrrrY = 0.toFloat()
        var wpcgefsZoom = 0.toFloat()
        var wpcgefsX = 0.toFloat()
        var wpcgefsY = 0.toFloat()
        var spcsseoZoom = 0.toFloat()
        var spcsseoX = 0.toFloat()
        var spcsseoY = 0.toFloat()
        var goesVisZoom = 0.toFloat()
        var goesVisX = 0.toFloat()
        var goesVisY = 0.toFloat()
        var goesVisSector = ""
        var nwsIconSize = 0
        var padding = 0
        var paddingSmall = 0
        var tabHeaders = arrayOf("", "", "", "")

        fun initPreferences(context: Context) {
            initRadarPreferences()
            UIPreferences.initPreferences(context)
            radarGeometrySetColors()
            listOf(94, 99, 134, 135, 159, 161, 163, 165, 172).forEach { radarColorPalette[it.toString()] = preferences.getString("RADAR_COLOR_PALETTE_" + it.toString(), "CODENH")}
            cardCorners = TypedValue.applyDimension(TypedValue.COMPLEX_UNIT_DIP, preferences.getInt("CARD_CORNER_RADIUS", 0).toFloat(), dm)
            telecineVideoSizePercentage = preferencesTelecine.getInt("video-size", 100)
            telecineSwitchShowCountdown = preferencesTelecine.getBoolean("show-countdown", false)
            telecineSwitchRecordingNotification = preferencesTelecine.getBoolean("recording-notification", false)
            telecineSwitchShowTouches = false
            vrButton = preferences.getString("VR_BUTTON", "false").startsWith("t")
            radarUseJni = preferences.getString("RADAR_USE_JNI", "false").startsWith("t")
            tileDownsize = preferences.getString("TILE_IMAGE_DOWNSIZE", "false").startsWith("t")
            iconsEvenSpaced = preferences.getString("UI_ICONS_EVENLY_SPACED", "true").startsWith("t")
            simpleMode = preferences.getString("SIMPLE_MODE", "").startsWith("t")
            checkspc = preferences.getString("CHECKSPC", "false").startsWith("t")
            checkwpc = preferences.getString("CHECKWPC", "false").startsWith("t")
            checktor = preferences.getString("CHECKTOR", "false").startsWith("t")
            nwsIconSize = preferences.getInt("NWS_ICON_SIZE_PREF", 24)
            uiAnimIconFrames = preferences.getString("UI_ANIM_ICON_FRAMES", "6")
            blackBg = preferences.getString("NWS_RADAR_BG_BLACK", "").startsWith("t")
            fullscreenMode = preferences.getString("FULLSCREEN_MODE", "false").startsWith("t")
            lockToolbars = preferences.getString("LOCK_TOOLBARS", "false").startsWith("t")
            alertOnlyonce = preferences.getString("ALERT_ONLYONCE", "false").startsWith("t")
            unitsM = preferences.getString("UNITS_M", "true").startsWith("t")
            unitsF = preferences.getString("UNITS_F", "true").startsWith("t")
            drawToolColor = preferences.getInt("DRAW_TOOL_COLOR", Color.rgb(255, 0, 0))
            widgetTextColor = preferences.getInt("WIDGET_TEXT_COLOR", Color.WHITE)
            widgetHighlightTextColor = preferences.getInt("WIDGET_HIGHLIGHT_TEXT_COLOR", Color.YELLOW)
            widgetNexradSize = preferences.getInt("WIDGET_NEXRAD_SIZE", 10)
            widgetCCShow7Day = preferences.getString("WIDGET_CC_DONOTSHOW_7_DAY", "true").startsWith("t")
            nwsIconTextColor = preferences.getInt("NWS_ICON_TEXT_COLOR", Color.rgb(38, 97, 139))
            nwsIconBottomColor = preferences.getInt("NWS_ICON_BOTTOM_COLOR", Color.rgb(255, 255, 255))
            nexradRadarBackgroundColor = preferences.getInt("NEXRAD_RADAR_BACKGROUND_COLOR", Color.rgb(0, 0, 0))
            wxoglSize = preferences.getInt("WXOGL_SIZE", 8)
            wxoglRememberLocation = preferences.getString("WXOGL_REMEMBER_LOCATION", "false").startsWith("t")
            wxoglRadarAutorefresh = preferences.getString("RADAR_AUTOREFRESH", "false").startsWith("t")
            wfoFav = preferences.getString("WFO_FAV", prefSeperator)
            ridFav = preferences.getString("RID_FAV", prefSeperator)
            sndFav = preferences.getString("SND_FAV", prefSeperator)
            srefFav = preferences.getString("SREF_FAV", prefSeperator)
            spcmesoFav = preferences.getString("SPCMESO_FAV", prefSeperator)
            spcmesoLabelFav = preferences.getString("SPCMESO_LABEL_FAV", prefSeperator)
            nwsTextFav = preferences.getString("NWS_TEXT_FAV", prefSeperator)
            notifSoundUri = preferences.getString("NOTIF_SOUND_URI", "")
            if (notifSoundUri == "") { notifSoundUri = Settings.System.DEFAULT_NOTIFICATION_URI.toString() }
            spotterFav = preferences.getString("SPOTTER_FAV", "")
            homescreenFav = preferences.getString("HOMESCREEN_FAV", HOMESCREEN_FAV_DEFAULT)
            locDisplayImg = homescreenFav.contains("OGL-RADAR") || homescreenFav.contains("NXRD")
            alertNotificationSoundTornadoCurrent = preferences.getString("ALERT_NOTIFICATION_SOUND_TORNADO", "").startsWith("t")
            alertNotificationSoundSpcmcd = preferences.getString("ALERT_NOTIFICATION_SOUND_SPCMCD", "").startsWith("t")
            alertNotificationSoundWpcmpd = preferences.getString("ALERT_NOTIFICATION_SOUND_WPCMPD", "").startsWith("t")
            alertNotificationSoundNhcEpac = preferences.getString("ALERT_NOTIFICATION_SOUND_NHC_EPAC", "").startsWith("t")
            alertNotificationSoundNhcAtl = preferences.getString("ALERT_NOTIFICATION_SOUND_NHC_ATL", "").startsWith("t")
            alertNotificationSoundSpcwat = preferences.getString("ALERT_NOTIFICATION_SOUND_SPCWAT", "").startsWith("t")
            alertNotificationSoundSpcswo = preferences.getString("ALERT_NOTIFICATION_SOUND_SPCSWO", "").startsWith("t")
            alertNotificationSoundTextProd = preferences.getString("ALERT_NOTIFICATION_SOUND_TEXT_PROD", "").startsWith("t")
            notifSoundRepeat = preferences.getString("NOTIF_SOUND_REPEAT", "").startsWith("t")
            notifTts = preferences.getString("NOTIF_TTS", "").startsWith("t")
            alertBlackoutAmCurrent = preferences.getInt("ALERT_BLACKOUT_AM", -1)
            alertBlackoutPmCurrent = preferences.getInt("ALERT_BLACKOUT_PM", -1)
            alertTornadoNotificationCurrent = preferences.getString("ALERT_TORNADO_NOTIFICATION", "").startsWith("t")
            alertSpcmcdNotificationCurrent = preferences.getString("ALERT_SPCMCD_NOTIFICATION", "").startsWith("t")
            alertSpcwatNotificationCurrent = preferences.getString("ALERT_SPCWAT_NOTIFICATION", "").startsWith("t")
            alertSpcswoNotificationCurrent = preferences.getString("ALERT_SPCSWO_NOTIFICATION", "").startsWith("t")
            alertSpcswoSlightNotificationCurrent = preferences.getString("ALERT_SPCSWO_SLIGHT_NOTIFICATION", "").startsWith("t")
            alertWpcmpdNotificationCurrent = preferences.getString("ALERT_WPCMPD_NOTIFICATION", "").startsWith("t")
            alertBlackoutTornadoCurrent = preferences.getString("ALERT_BLACKOUT_TORNADO", "").startsWith("t")
            alertNhcEpacNotificationCurrent = preferences.getString("ALERT_NHC_EPAC_NOTIFICATION", "").startsWith("t")
            alertNhcAtlNotificationCurrent = preferences.getString("ALERT_NHC_ATL_NOTIFICATION", "").startsWith("t")
            alertAutocancel = preferences.getString("ALERT_AUTOCANCEL", "false").startsWith("t")
            alertBlackout = preferences.getString("ALERT_BLACKOUT", "").startsWith("t")
            playlistStr = preferences.getString("PLAYLIST", "")
            notifTextProdStr = preferences.getString(UtilityNotificationTextProduct.PREF_TOKEN, "")
            radarColorPalette94List = preferences.getString("RADAR_COLOR_PALETTE_94_LIST", "")
            radarColorPalette99List = preferences.getString("RADAR_COLOR_PALETTE_99_LIST", "")
            wxoglZoom = preferences.getFloat("WXOGL_ZOOM", wxoglSize.toFloat() / 10.0f)
            wxoglRid = preferences.getString("WXOGL_RID", "")
            wxoglProd = preferences.getString("WXOGL_PROD", "N0Q")
            wxoglX = preferences.getFloat("WXOGL_X", 0.0f)
            wxoglY = preferences.getFloat("WXOGL_Y", 0.0f)
            Location.currentLocationStr = preferences.getString("CURRENT_LOC_FRAGMENT", "1")
            severeDashboardTor.update(context)
            severeDashboardTst.update(context)
            severeDashboardFfw.update(context)
            severeDashboardWat.update(context)
            severeDashboardMcd.update(context)
            severeDashboardMpd.update(context)
            watchLatlon.update(context)
            watchLatlonTor.update(context)
            mcdLatlon.update(context)
            mcdNoList.update(context)
            mpdLatlon.update(context)
            mpdNoList.update(context)
            wfoTextFav = preferences.getString("WFO_TEXT_FAV", "AFD")
            wpcTextFav = preferences.getString("WPC_TEXT_FAV", "pmdspd")
            spchrrrZoom = preferences.getFloat("SPCHRRR_ZOOM", 1.0f)
            spchrrrX = preferences.getFloat("SPCHRRR_X", 0.5f)
            spchrrrY = preferences.getFloat("SPCHRRR_Y", 0.5f)
            wpcgefsZoom = preferences.getFloat("WPCGEFS_ZOOM", 1.0f)
            wpcgefsX = preferences.getFloat("WPCGEFS_X", 0.5f)
            wpcgefsY = preferences.getFloat("WPCGEFS_Y", 0.5f)
            spcsseoZoom = preferences.getFloat("SPCSSEO_ZOOM", 1.0f)
            spcsseoX = preferences.getFloat("SPCSSEO_X", 0.5f)
            spcsseoY = preferences.getFloat("SPCSSEO_Y", 0.5f)
            goesVisZoom = preferences.getFloat("GOESVIS_ZOOM", 1.0f)
            goesVisX = preferences.getFloat("GOESVIS_X", 0.5f)
            goesVisY = preferences.getFloat("GOESVIS_Y", 0.5f)
            goesVisSector = preferences.getString("GOESVIS_SECTOR", "")
            elevationPref = preferences.getInt("ELEVATION_PREF", 0).toFloat()
            elevationPref = TypedValue.applyDimension(TypedValue.COMPLEX_UNIT_DIP, elevationPref, dm)
            cardElevation = elevationPref
            fabElevation = elevationPref
            fabElevationDepressed = elevationPref * 2
            tabHeaders[0] = preferences.getString("TAB1_HEADER", "LOCAL")
            tabHeaders[1] = preferences.getString("TAB2_HEADER", "SPC")
            tabHeaders[2] = preferences.getString("TAB3_HEADER", "MISC")
            tabHeaders[3] = preferences.getString("TAB4_HEADER", "IMAGES")
        }

        // FIXME move to Location
        //private val locations = mutableListOf<Location>()
        val locations = mutableListOf<Location>()

        // source for county and state lines
        // http://www2.census.gov/geo/tiger/GENZ2010/
        // gz_2010_us_040_00_20m.kml
        //
        // cb_2014_us_county_20m.kml
        // https://www.census.gov/geo/maps-data/data/kml/kml_counties.html
        // ./android-sdk-linux/platform-tools/adb pull /data/data/joshuatee.wx/files/statev3.bin

        val colorMap = mutableMapOf<Int, ObjectColorPalette>()
        var loadedBuffers = false

        fun initBuffers(context: Context) {
            UtilityLog.d("wx","initBuffers ran")
            loadedBuffers = true
            ColorPalettes.init(context)
            initRadarGeometryAll(context)
            GeographyType.refresh()
        }

        private const val caResid = R.raw.ca
        private const val mxResid = R.raw.mx
        private const val caCnt = 161792
        private const val mxCnt = 151552

        var stateRelativeBuffer: ByteBuffer = ByteBuffer.allocateDirect(0)
        var countState = 200000 // v3 205748
        var hwRelativeBuffer: ByteBuffer = ByteBuffer.allocateDirect(0)
        var countHw = 862208 // on disk size 3448832 yields  862208
        var hwExtRelativeBuffer: ByteBuffer = ByteBuffer.allocateDirect(0)
        const val countHwExt = 770048 // on disk 3080192 yields 770048
        private const val hwExtFileResid = R.raw.hwv4ext // 2016_04_06
        var lakesRelativeBuffer: ByteBuffer = ByteBuffer.allocateDirect(0)
        const val countLakes = 503808 // was 14336 + 489476
        var countyRelativeBuffer: ByteBuffer = ByteBuffer.allocateDirect(0)
        var countCounty = 212992 // file on disk is 851968, should be
        private var hwFileResid = R.raw.hwv4
        private const val lakesFileResid = R.raw.lakesv3
        private var countyFileResid = R.raw.county

        var radarColorHw = 0
        var radarColorHwExt = 0
        var radarColorState = 0
        var radarColorTstorm = 0
        var radarColorTstormWatch = 0
        var radarColorTor = 0
        var radarColorTorWatch = 0
        var radarColorFfw = 0
        var radarColorMcd = 0
        var radarColorMpd = 0
        var radarColorLocdot = 0
        var radarColorSpotter = 0
        var radarColorCity = 0
        var radarColorLakes = 0
        var radarColorCounty = 0
        var radarColorSti = 0
        var radarColorHi = 0
        var radarColorObs = 0
        var radarColorObsWindbarbs = 0
        var radarColorCountyLabels = 0

        private fun radarGeometrySetColors() {
            radarColorHw = preferences.getInt("RADAR_COLOR_HW", Color.rgb(135, 135, 135))
            radarColorHwExt = preferences.getInt("RADAR_COLOR_HW_EXT", Color.rgb(91, 91, 91))
            radarColorState = preferences.getInt("RADAR_COLOR_STATE", Color.rgb(142, 142, 142))
            radarColorTstorm = preferences.getInt("RADAR_COLOR_TSTORM", Color.rgb(255, 255, 0))
            radarColorTstormWatch = preferences.getInt("RADAR_COLOR_TSTORM_WATCH", Color.rgb(255, 187, 0))
            radarColorTor = preferences.getInt("RADAR_COLOR_TOR", Color.rgb(243, 85, 243))
            radarColorTorWatch = preferences.getInt("RADAR_COLOR_TOR_WATCH", Color.rgb(255, 0, 0))
            radarColorFfw = preferences.getInt("RADAR_COLOR_FFW", Color.rgb(0, 255, 0))
            radarColorMcd = preferences.getInt("RADAR_COLOR_MCD", Color.rgb(153, 51, 255))
            radarColorMpd = preferences.getInt("RADAR_COLOR_MPD", Color.rgb(0, 255, 0))
            radarColorLocdot = preferences.getInt("RADAR_COLOR_LOCDOT", Color.rgb(255, 255, 255))
            radarColorSpotter = preferences.getInt("RADAR_COLOR_SPOTTER", Color.rgb(255, 0, 245))
            radarColorCity = preferences.getInt("RADAR_COLOR_CITY", Color.rgb(255, 255, 255))
            radarColorLakes = preferences.getInt("RADAR_COLOR_LAKES", Color.rgb(0, 0, 255))
            radarColorCounty = preferences.getInt("RADAR_COLOR_COUNTY", Color.rgb(75, 75, 75))
            radarColorSti = preferences.getInt("RADAR_COLOR_STI", Color.rgb(255, 255, 255))
            radarColorHi = preferences.getInt("RADAR_COLOR_HI", Color.rgb(0, 255, 0))
            radarColorObs = preferences.getInt("RADAR_COLOR_OBS", Color.rgb(255, 255, 255))
            radarColorObsWindbarbs = preferences.getInt("RADAR_COLOR_OBS_WINDBARBS", Color.rgb(255, 255, 255))
            radarColorCountyLabels = preferences.getInt("RADAR_COLOR_COUNTY_LABELS", Color.rgb(234, 214, 123))
        }

        private fun initRadarGeometryAll(context: Context) = GeographyType.values().forEach { initRadarGeometryByType(context, it)}

        fun initRadarGeometryByType(context: Context, type:GeographyType) {
            if (!radarHwEnh) {
                hwFileResid = R.raw.hw
                countHw = 112640
            }
            var stateLinesFileResid = R.raw.statev2
            countState = 205748
            if (radarStateHires) {
                stateLinesFileResid = R.raw.statev3
                countState = 1166552
            }
            if (radarCamxBorders) {
                countState += caCnt + mxCnt
            }
            if (radarCountyHires) {
                countyFileResid = R.raw.countyv2
                countCounty = 820852
            }
            val fileidArr = listOf(lakesFileResid, hwFileResid, countyFileResid, stateLinesFileResid, caResid, mxResid, hwExtFileResid)
            val countArr = listOf(countLakes, countHw, countCounty, countState, caCnt, mxCnt, countHwExt)
            val prefArr = listOf(true, true, true, true, radarCamxBorders, radarCamxBorders, radarHwEnhExt)
            when(type){
                GeographyType.STATE_LINES -> {
                    stateRelativeBuffer = ByteBuffer.allocateDirect(4 * countState)
                    stateRelativeBuffer.order(ByteOrder.nativeOrder())
                    stateRelativeBuffer.position(0)
                    listOf(3,4,5).forEach {loadBuffer(context, fileidArr[it], stateRelativeBuffer, countArr[it], prefArr[it])}
                }
                GeographyType.HIGHWAYS -> {
                    hwRelativeBuffer = ByteBuffer.allocateDirect(4 * countHw)
                    hwRelativeBuffer.order(ByteOrder.nativeOrder())
                    hwRelativeBuffer.position(0)
                    for (s in intArrayOf(1)) { loadBuffer(context, fileidArr[s], hwRelativeBuffer, countArr[s], prefArr[s]) }
                }
                GeographyType.HIGHWAYS_EXTENDED -> {
                    if (radarHwEnhExt) {
                        hwExtRelativeBuffer = ByteBuffer.allocateDirect(4 * countHwExt)
                        hwExtRelativeBuffer.order(ByteOrder.nativeOrder())
                        hwExtRelativeBuffer.position(0)
                    }
                    for (s in intArrayOf(6)) { loadBuffer(context, fileidArr[s], hwExtRelativeBuffer, countArr[s], prefArr[s]) }
                }
                GeographyType.LAKES -> {
                    lakesRelativeBuffer = ByteBuffer.allocateDirect(4 * countLakes)
                    lakesRelativeBuffer.order(ByteOrder.nativeOrder())
                    lakesRelativeBuffer.position(0)
                    val s = 0
                    loadBuffer(context, fileidArr[s], lakesRelativeBuffer, countArr[s], prefArr[s])
                }
                GeographyType.COUNTY_LINES -> {
                    countyRelativeBuffer = ByteBuffer.allocateDirect(4 * countCounty)
                    countyRelativeBuffer.order(ByteOrder.nativeOrder())
                    countyRelativeBuffer.position(0)
                    val s = 2
                    loadBuffer(context, fileidArr[s], countyRelativeBuffer, countArr[s], prefArr[s])
                }
                else -> {}
            }
        }

        private fun loadBuffer(context: Context, fileID: Int, bb: ByteBuffer, count: Int, pref: Boolean) {
            if (pref) {
                try {
                    val inputStream = context.resources.openRawResource(fileID)
                    val dis = DataInputStream(BufferedInputStream(inputStream))
                    (0 until count).forEach { bb.putFloat(dis.readFloat()) }
                    dis.close()
                    inputStream.close()
                } catch (e: IOException) { UtilityLog.HandleException(e) }
            }
        }

        // Radar Preferences
        const val NWS_RADAR_PUB = "http://tgftp.nws.noaa.gov/" //(Official current URL, problem with cricket but so does cp.ncep now )
        //public static final String NWS_RADAR_PUB = "http://tgftp.cp.ncep.noaa.gov/";
        const val nwsRadarLevel2Pub = "http://nomads.ncep.noaa.gov/pub/data/nccf/radar/nexrad_level2/"

        var radarWarnings = false
        var locdotFollowsGps = false
        var dualpaneshareposn = false
        var radarSpotters = false
        var radarSpottersLabel = false
        var radarObs = false
        var radarObsWindbarbs = false
        var radarSwo = false

        var radarCities = false
        var radarHw = false
        var radarLocDot = false
        var radarLakes = false
        var radarCounty = false
        var radarCountyLabels = false
        private var radarCountyHires = false
        private var radarStateHires = false
        var radarWatMcd = false
        var radarMpd = false
        var radarSti = false
        var radarHi = false
        var radarTvs = false

        var radarShowLegend = false
        var drawtoolSize = 0
        var radarObsExtZoom = 0
        var radarSpotterSize = 0
        var radarAviationSize = 0
        var radarTextSize = 0.toFloat()
        var radarLocdotSize = 0
        var radarHiSize = 0
        var radarTvsSize = 0
        var radarWarnLinesize = 0
        var radarWatmcdLinesize = 0
        private var radarHwEnh = false
        var radarHwEnhExt = false
        private var radarCamxBorders = false
        var radarIconsLevel2 = false

        private fun initRadarPreferences() {
            radarWarnings = preferences.getString("COD_WARNINGS_DEFAULT", "false").startsWith("t")
            locdotFollowsGps = preferences.getString("LOCDOT_FOLLOWS_GPS", "false").startsWith("t")
            dualpaneshareposn = preferences.getString("DUALPANE_SHARE_POSN", "true").startsWith("t")
            radarSpotters = preferences.getString("WXOGL_SPOTTERS", "false").startsWith("t")
            radarSpottersLabel = preferences.getString("WXOGL_SPOTTERS_LABEL", "false").startsWith("t")
            radarObs = preferences.getString("WXOGL_OBS", "false").startsWith("t")
            radarObsWindbarbs = preferences.getString("WXOGL_OBS_WINDBARBS", "false").startsWith("t")
            radarSwo = preferences.getString("RADAR_SHOW_SWO", "false").startsWith("t")
            radarCities = preferences.getString("COD_CITIES_DEFAULT", "").startsWith("t")
            radarHw = preferences.getString("COD_HW_DEFAULT", "true").startsWith("t")
            radarLocDot = preferences.getString("COD_LOCDOT_DEFAULT", "true").startsWith("t")
            radarLakes = preferences.getString("COD_LAKES_DEFAULT", "false").startsWith("t")
            radarCounty = preferences.getString("RADAR_SHOW_COUNTY", "true").startsWith("t")
            radarWatMcd = preferences.getString("RADAR_SHOW_WATCH", "false").startsWith("t")
            radarMpd = preferences.getString("RADAR_SHOW_MPD", "false").startsWith("t")
            radarSti = preferences.getString("RADAR_SHOW_STI", "false").startsWith("t")
            radarHi = preferences.getString("RADAR_SHOW_HI", "false").startsWith("t")
            radarTvs = preferences.getString("RADAR_SHOW_TVS", "false").startsWith("t")
            radarHwEnh = preferences.getString("RADAR_HW_ENH", "false").startsWith("t")
            radarHwEnh = preferences.getString("RADAR_HW_ENH", "true").startsWith("t")
            radarHwEnhExt = preferences.getString("RADAR_HW_ENH_EXT", "false").startsWith("t")
            radarCamxBorders = preferences.getString("RADAR_CAMX_BORDERS", "false").startsWith("t")
            radarCountyLabels = preferences.getString("RADAR_COUNTY_LABELS", "false").startsWith("t")
            radarCountyHires = preferences.getString("RADAR_COUNTY_HIRES", "false").startsWith("t")
            radarStateHires = preferences.getString("RADAR_STATE_HIRES", "false").startsWith("t")
            radarIconsLevel2 = preferences.getString("WXOGL_ICONS_LEVEL2", "false").startsWith("t")

            radarShowLegend = preferences.getString("RADAR_SHOW_LEGEND", "false").startsWith("t")
            drawtoolSize = preferences.getInt("DRAWTOOL_SIZE", 4)
            radarObsExtZoom = preferences.getInt("RADAR_OBS_EXT_ZOOM", 7)
            radarSpotterSize = preferences.getInt("RADAR_SPOTTER_SIZE", 4)
            radarAviationSize = preferences.getInt("RADAR_AVIATION_SIZE", 7)
            radarTextSize = preferences.getFloat("RADAR_TEXT_SIZE", 1.0f)
            radarLocdotSize = preferences.getInt("RADAR_LOCDOT_SIZE", 8)
            radarHiSize = preferences.getInt("RADAR_HI_SIZE", 8)
            radarTvsSize = preferences.getInt("RADAR_TVS_SIZE", 8)
            radarWarnLinesize = preferences.getInt("RADAR_WARN_LINESIZE", 2)
            radarWatmcdLinesize = preferences.getInt("RADAR_WATMCD_LINESIZE", 2)
        }


    } // end companion object
}
