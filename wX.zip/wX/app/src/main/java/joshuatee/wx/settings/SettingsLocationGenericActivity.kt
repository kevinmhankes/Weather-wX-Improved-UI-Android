/*

    Copyright 2013, 2014, 2015, 2016, 2017, 2018  joshua.tee@gmail.com

    This file is part of wX.

    wX is free software: you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation, either version 3 of the License, or
    (at your option) any later version.

    wX is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with wX.  If not, see <http://www.gnu.org/licenses/>.

 */

package joshuatee.wx.settings

import java.util.Locale

import android.Manifest
import android.annotation.SuppressLint
import android.app.Activity
import android.content.Context
import android.content.pm.PackageManager
import android.graphics.Color
import android.os.AsyncTask
import android.os.Build
import android.os.Bundle
import android.speech.RecognizerIntent
import android.support.v4.app.ActivityCompat
import android.support.v4.content.ContextCompat
import android.support.v7.widget.SearchView
import android.support.v7.widget.SwitchCompat
import android.support.v7.widget.SearchView.OnQueryTextListener
import android.support.v7.widget.Toolbar.OnMenuItemClickListener
import android.view.ViewGroup
import android.widget.CompoundButton.OnCheckedChangeListener
import android.content.Intent
import android.view.Menu
import android.view.MenuItem
import android.view.View
import android.view.View.OnClickListener
import android.widget.*

import joshuatee.wx.R
import joshuatee.wx.canada.UtilityCitiesCA
import joshuatee.wx.MyApplication
import joshuatee.wx.UIPreferences
import joshuatee.wx.ui.BaseActivity
import joshuatee.wx.ui.ObjectCard
import joshuatee.wx.ui.ObjectFab
import joshuatee.wx.util.UtilityAlertDialog
import joshuatee.wx.util.UtilityCities
import joshuatee.wx.ui.UtilityUI
import joshuatee.wx.activitiesmisc.WebscreenAB
import joshuatee.wx.notifications.UtilityWXJobService
import joshuatee.wx.objects.ObjectIntent
import joshuatee.wx.util.Utility
import joshuatee.wx.util.UtilityMap

class SettingsLocationGenericActivity : BaseActivity(), OnCheckedChangeListener, OnClickListener, OnMenuItemClickListener {

    // manual interface for searching and saving a location
    //

    companion object { const val LOC_NUM = "" }

    private var locXStr = ""
    private var locYStr = ""
    private val REQUEST_OK = 1
    private var updateTitle = true
    private var locLabelCurrent = ""
    private var locNum = ""
    private var locNumToSaveStr = ""
    private lateinit var alertRadar1Sw: SwitchCompat
    private lateinit var alertSoundSw: SwitchCompat
    private lateinit var alert7Day1Sw: SwitchCompat
    private lateinit var alertCcSw: SwitchCompat
    private lateinit var alertSw: SwitchCompat
    private lateinit var alertMcdSw: SwitchCompat
    private lateinit var alertSwoSw: SwitchCompat
    private lateinit var alertSpcfwSw: SwitchCompat
    private lateinit var alertWpcmpdSw: SwitchCompat
    private lateinit var locXEt: EditText
    private lateinit var locYEt: EditText
    private lateinit var locLabelEt: EditText
    private lateinit var cityAa: ArrayAdapter<String>
    private lateinit var cv7: ObjectCard
    private lateinit var cv8: ObjectCard
    private lateinit var cv9: ObjectCard
    private lateinit var cv10: ObjectCard
    private lateinit var rl: RelativeLayout
    private var menuLocal: Menu? = null
    private lateinit var contextg: Context

    @SuppressLint("MissingSuperCall")
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState, R.layout.activity_settings_location_generic, R.menu.settings_location_generic_bottom, true)
        contextg = this
        toolbarBottom.setOnMenuItemClickListener(this)
        Utility.writePref(this,"LOCATION_CANADA_PROV", "")
        Utility.writePref(this, "LOCATION_CANADA_CITY", "")
        Utility.writePref(this, "LOCATION_CANADA_ID", "")
        val fab = ObjectFab(this, this, R.id.fab)
        fab.setOnClickListener(OnClickListener { fabSaveLocation() })
        val me = toolbarBottom.menu
        listOf(R.id.cv1,R.id.cv2,R.id.cv3,R.id.cv4,R.id.cv5,R.id.cv6).forEach{ObjectCard(this, it)}
        cv7 = ObjectCard(this, R.id.cv7)
        cv8 = ObjectCard(this, R.id.cv8)
        cv9 = ObjectCard(this, R.id.cv9)
        cv10 = ObjectCard(this, R.id.cv10)
        rl = findViewById(R.id.rl)
        val textviewResId = listOf(R.id.alert_switch_text, R.id.alert_cc_switch_text, R.id.alert_7day_1_switch_text, R.id.alert_sound_switch_text, R.id.alert_radar1_switch_text, R.id.alert_mcd_switch_text, R.id.alert_swo_switch_text, R.id.alert_spcfw_switch_text, R.id.alert_wpcmpd_switch_text)
        textviewResId.forEach {
            val tv:TextView = findViewById(it)
            tv.setOnClickListener(this)
        }
        val locNumArr = intent.getStringArrayExtra(LOC_NUM)
        locNum = locNumArr[0]
        val locNumInt = locNum.toIntOrNull() ?: 0
        title = "Location $locNum"
        locXStr = Utility.readPref(this, "LOC" + locNum + "_X", "")
        locYStr = Utility.readPref(this, "LOC" + locNum + "_Y", "")
        var alertNotificationCurrent: String = Utility.readPref(this, "ALERT" + locNum + "_NOTIFICATION", "false")
        var alertNotificationRadarCurrent: String = Utility.readPref(this, "ALERT_NOTIFICATION_RADAR$locNum", "false")
        var alertCcNotificationCurrent: String = Utility.readPref(this, "ALERT_CC" + locNum + "_NOTIFICATION", "false")
        var alert7Day1NotificationCurrent: String = Utility.readPref(this, "ALERT_7DAY_" + locNum + "_NOTIFICATION", "false")
        var alertNotificationSoundCurrent: String = Utility.readPref(this, "ALERT_NOTIFICATION_SOUND$locNum", "false")
        var alertNotificationMcdCurrent: String = Utility.readPref(this, "ALERT_NOTIFICATION_MCD$locNum", "false")
        var alertNotificationSwoCurrent: String = Utility.readPref(this, "ALERT_NOTIFICATION_SWO$locNum", "false")
        var alertNotificationSpcfwCurrent: String = Utility.readPref(this, "ALERT_NOTIFICATION_SPCFW$locNum", "false")
        var alertNotificationWpcmpdCurrent: String = Utility.readPref(this, "ALERT_NOTIFICATION_WPCMPD$locNum", "false")
        locLabelCurrent = Utility.readPref(this, "LOC" + locNum + "_LABEL", "")
        val locNumIntCurrent = Location.numLocations
        if (locNumInt == locNumIntCurrent + 1) {
            updateTitle = false
            locNumToSaveStr = locNumIntCurrent.toString()
            locLabelCurrent = "Location $locNum"
            //
            // needed to prevent old location(deleted) data from showing up when adding new
            //
            locXStr = ""
            locYStr = ""
            alertNotificationCurrent = "false"
            alertNotificationRadarCurrent = "false"
            alertCcNotificationCurrent = "false"
            alert7Day1NotificationCurrent = "false"
            alertNotificationSoundCurrent = "false"
            alertNotificationMcdCurrent = "false"
            alertNotificationSwoCurrent = "false"
            alertNotificationSpcfwCurrent = "false"
            alertNotificationWpcmpdCurrent = "false"
        }
        updateSubTitle()
        val delB = me.findItem(R.id.action_delete)
        delB.isVisible = locNumIntCurrent > 1
        locLabelEt = findViewById(R.id.loc_label_text)
        locLabelEt.setText(locLabelCurrent)
        locXEt = findViewById(R.id.loc_lat_text)
        locXEt.setText(locXStr)
        locYEt = findViewById(R.id.loc_lon_text)
        locYEt.setText(locYStr)
        if (UIPreferences.themeInt == R.style.MyCustomTheme_white_NOAB) {
            locLabelEt.setTextColor(Color.BLACK)
            locXEt.setTextColor(Color.BLACK)
            locYEt.setTextColor(Color.BLACK)
            locLabelEt.setHintTextColor(Color.GRAY)
            locXEt.setHintTextColor(Color.GRAY)
            locYEt.setHintTextColor(Color.GRAY)
        }
        alertSw = findViewById(R.id.alert_switch)
        alertSw.setOnCheckedChangeListener(this)
        alertSw.isChecked = alertNotificationCurrent == "true"
        alertCcSw = findViewById(R.id.alert_cc_switch)
        alertCcSw.setOnCheckedChangeListener(this)
        alertCcSw.isChecked = alertCcNotificationCurrent == "true"
        alert7Day1Sw = findViewById(R.id.alert_7day_1_switch)
        alert7Day1Sw.setOnCheckedChangeListener(this)
        alert7Day1Sw.isChecked = alert7Day1NotificationCurrent == "true"
        alertSoundSw = findViewById(R.id.alert_sound_switch)
        alertSoundSw.setOnCheckedChangeListener(this)
        alertSoundSw.isChecked = alertNotificationSoundCurrent == "true"
        alertRadar1Sw = findViewById(R.id.alert_radar1_switch)
        alertRadar1Sw.setOnCheckedChangeListener(this)
        alertRadar1Sw.isChecked = alertNotificationRadarCurrent == "true"
        alertMcdSw = findViewById(R.id.alert_mcd_switch)
        alertMcdSw.setOnCheckedChangeListener(this)
        alertMcdSw.isChecked = alertNotificationMcdCurrent == "true"
        alertSwoSw = findViewById(R.id.alert_swo_switch)
        alertSwoSw.setOnCheckedChangeListener(this)
        alertSwoSw.isChecked = alertNotificationSwoCurrent == "true"
        alertSpcfwSw = findViewById(R.id.alert_spcfw_switch)
        alertSpcfwSw.setOnCheckedChangeListener(this)
        alertSpcfwSw.isChecked = alertNotificationSpcfwCurrent == "true"
        alertWpcmpdSw = findViewById(R.id.alert_wpcmpd_switch)
        alertWpcmpdSw.setOnCheckedChangeListener(this)
        alertWpcmpdSw.isChecked = alertNotificationWpcmpdCurrent == "true"
        hideNONUSNotifs()
        if (locNumArr[1] != "") {
            if (locNumArr[1] == " roaming") {
                locLabelEt.setText(locNumArr[1].toUpperCase(Locale.US))
                GPSAndSave().executeOnExecutor(AsyncTask.THREAD_POOL_EXECUTOR, "osm", locNum, locNumArr[1].toUpperCase(Locale.US))
            } else {
                val addrSend = locNumArr[1].replace(" ", "+")
                locLabelEt.setText(locNumArr[1])
                AddressSearchAndSave().executeOnExecutor(AsyncTask.THREAD_POOL_EXECUTOR, "osm", locNum, addrSend, locNumArr[1])
            }
        }
    }

    override fun onClick(v2: View) {
        when (v2.id) {
            R.id.alert_switch_text -> showHelpText(resources.getString(R.string.alert_switch_text))
            R.id.alert_cc_switch_text -> showHelpText(resources.getString(R.string.alert_cc_switch_text))
            R.id.alert_7day_1_switch_text -> showHelpText(resources.getString(R.string.alert_7day_1_switch_text))
            R.id.alert_sound_switch_text -> showHelpText(resources.getString(R.string.alert_sound_switch_text))
            R.id.alert_radar1_switch_text -> showHelpText(resources.getString(R.string.alert_radar1_switch_text))
            R.id.alert_mcd_switch_text -> showHelpText(resources.getString(R.string.alert_mcd_switch_text))
            R.id.alert_swo_switch_text -> showHelpText(resources.getString(R.string.alert_swo_switch_text))
            R.id.alert_spcfw_switch_text -> showHelpText(resources.getString(R.string.alert_spcfw_switch_text))
            R.id.alert_wpcmpd_switch_text -> showHelpText(resources.getString(R.string.alert_wpcmpd_switch_text))
        }
    }

    private fun showHelpText(helpStr: String) { UtilityAlertDialog.showHelpText(helpStr, this) }

    override fun onCheckedChanged(buttonView: CompoundButton, isChecked: Boolean) {

        when (buttonView.id) {
            R.id.alert_switch -> {
                val on = buttonView.isChecked
                if (on) {
                    Utility.writePref(this,"ALERT" + locNum + "_NOTIFICATION", "true")
                } else {
                    Utility.writePref(this,"ALERT" + locNum + "_NOTIFICATION", "false")
                }
                Utility.writePref(this,"RESTART_NOTIF", "true")
            }
            R.id.alert_cc_switch -> {
                val on = buttonView.isChecked
                if (on) {
                    Utility.writePref(this,"ALERT_CC" + locNum + "_NOTIFICATION", "true")
                } else {
                    Utility.writePref(this,"ALERT_CC" + locNum + "_NOTIFICATION", "false")
                }
                Utility.writePref(this,"RESTART_NOTIF", "true")
            }
            R.id.alert_7day_1_switch -> {
                val on = buttonView.isChecked
                if (on) {
                    Utility.writePref(this,"ALERT_7DAY_" + locNum + "_NOTIFICATION", "true")
                } else {
                    Utility.writePref(this,"ALERT_7DAY_" + locNum + "_NOTIFICATION", "false")
                }
                Utility.writePref(this,"RESTART_NOTIF", "true")
            }
            R.id.alert_sound_switch -> {
                val on = buttonView.isChecked
                if (on) {
                    Utility.writePref(this,"ALERT_NOTIFICATION_SOUND$locNum", "true")
                } else {
                    Utility.writePref(this,"ALERT_NOTIFICATION_SOUND$locNum", "false")
                }
            }
            R.id.alert_radar1_switch -> {
                val on = buttonView.isChecked
                if (on) {
                    Utility.writePref(this,"ALERT_NOTIFICATION_RADAR$locNum", "true")
                } else {
                    Utility.writePref(this,"ALERT_NOTIFICATION_RADAR$locNum", "false")
                }
                Utility.writePref(this,"RESTART_NOTIF", "true")
            }
            R.id.alert_mcd_switch -> {
                val on = buttonView.isChecked
                if (on) {
                    Utility.writePref(this,"ALERT_NOTIFICATION_MCD$locNum", "true")
                } else {
                    Utility.writePref(this,"ALERT_NOTIFICATION_MCD$locNum", "false")
                }
                Utility.writePref(this,"RESTART_NOTIF", "true")
            }
            R.id.alert_swo_switch -> {
                val on = buttonView.isChecked
                if (on) {
                    Utility.writePref(this,"ALERT_NOTIFICATION_SWO$locNum", "true")
                } else {
                    Utility.writePref(this,"ALERT_NOTIFICATION_SWO$locNum", "false")
                }
                Utility.writePref(this,"RESTART_NOTIF", "true")
            }
            R.id.alert_spcfw_switch -> {
                val on = buttonView.isChecked
                if (on) {
                    Utility.writePref(this,"ALERT_NOTIFICATION_SPCFW$locNum", "true")
                } else {
                    Utility.writePref(this,"ALERT_NOTIFICATION_SPCFW$locNum", "false")
                }
                Utility.writePref(this,"RESTART_NOTIF", "true")
            }
            R.id.alert_wpcmpd_switch -> {
                val on = buttonView.isChecked
                if (on) {
                    Utility.writePref(this, "ALERT_NOTIFICATION_WPCMPD$locNum", "true")
                } else {
                    Utility.writePref(this,"ALERT_NOTIFICATION_WPCMPD$locNum", "false")
                }
                Utility.writePref(this,"RESTART_NOTIF", "true")
            }
        }
    }

    override fun onRestart() {
        val caProv = Utility.readPref(this, "LOCATION_CANADA_PROV", "")
        val caCity = Utility.readPref(this, "LOCATION_CANADA_CITY", "")
        val caId = Utility.readPref(this, "LOCATION_CANADA_ID", "")
        if (caProv != "" || caCity != "" || caId != "") {
            locXEt.setText(resources.getString(R.string.settings_loc_generic_ca_x, caProv))
            locYEt.setText(caId)
            locLabelEt.setText("$caCity, $caProv")
            hideNotifsCA()
        }
        afterDelete()
        super.onRestart()
    }

    private fun afterDelete() {
        val alertNotificationCurrent = Utility.readPref(this, "ALERT" + locNum + "_NOTIFICATION", "false")
        val alertNotificationRadarCurrent = Utility.readPref(this, "ALERT_NOTIFICATION_RADAR$locNum", "false")
        val alertCcNotificationCurrent = Utility.readPref(this, "ALERT_CC" + locNum + "_NOTIFICATION", "false")
        val alert7Day1NotificationCurrent = Utility.readPref(this, "ALERT_7DAY_" + locNum + "_NOTIFICATION", "false")
        val alertNotificationSoundCurrent = Utility.readPref(this, "ALERT_NOTIFICATION_SOUND$locNum", "false")
        val alertNotificationMcdCurrent = Utility.readPref(this, "ALERT_NOTIFICATION_MCD$locNum", "false")
        val alertNotificationSwoCurrent = Utility.readPref(this, "ALERT_NOTIFICATION_SWO$locNum", "false")
        val alertNotificationSpcfwCurrent = Utility.readPref(this, "ALERT_NOTIFICATION_SPCFW$locNum", "false")
        val alertNotificationWpcmpdCurrent = Utility.readPref(this, "ALERT_NOTIFICATION_WPCMPD$locNum", "false")
        alertRadar1Sw.visibility = View.VISIBLE
        alertSoundSw.visibility = View.VISIBLE
        alert7Day1Sw.visibility = View.VISIBLE
        alertCcSw.visibility = View.VISIBLE
        alertSw.visibility = View.VISIBLE
        alertMcdSw.visibility = View.VISIBLE
        alertSwoSw.visibility = View.VISIBLE
        alertSpcfwSw.visibility = View.VISIBLE
        alertWpcmpdSw.visibility = View.VISIBLE
        val textviewResID = listOf(R.id.notif_text, R.id.alert_switch_text, R.id.alert_cc_switch_text, R.id.alert_7day_1_switch_text, R.id.alert_sound_switch_text, R.id.alert_radar1_switch_text, R.id.alert_mcd_switch_text, R.id.alert_swo_switch_text, R.id.alert_spcfw_switch_text, R.id.alert_wpcmpd_switch_text)
        textviewResID.forEach {
            val tv:TextView = findViewById(it)
            tv.visibility = View.VISIBLE
        }
        alertSw = findViewById(R.id.alert_switch)
        alertSw.setOnCheckedChangeListener(this)
        alertSw.isChecked = alertNotificationCurrent == "true"
        alertCcSw = findViewById(R.id.alert_cc_switch)
        alertCcSw.setOnCheckedChangeListener(this)
        alertCcSw.isChecked = alertCcNotificationCurrent == "true"
        alert7Day1Sw = findViewById(R.id.alert_7day_1_switch)
        alert7Day1Sw.setOnCheckedChangeListener(this)
        alert7Day1Sw.isChecked = alert7Day1NotificationCurrent == "true"
        alertSoundSw = findViewById(R.id.alert_sound_switch)
        alertSoundSw.setOnCheckedChangeListener(this)
        alertSoundSw.isChecked = alertNotificationSoundCurrent == "true"
        alertRadar1Sw = findViewById(R.id.alert_radar1_switch)
        alertRadar1Sw.setOnCheckedChangeListener(this)
        alertRadar1Sw.isChecked = alertNotificationRadarCurrent == "true"
        alertMcdSw = findViewById(R.id.alert_mcd_switch)
        alertMcdSw.setOnCheckedChangeListener(this)
        alertMcdSw.isChecked = alertNotificationMcdCurrent == "true"
        alertSwoSw = findViewById(R.id.alert_swo_switch)
        alertSwoSw.setOnCheckedChangeListener(this)
        alertSwoSw.isChecked = alertNotificationSwoCurrent == "true"
        alertSpcfwSw = findViewById(R.id.alert_spcfw_switch)
        alertSpcfwSw.setOnCheckedChangeListener(this)
        alertSpcfwSw.isChecked = alertNotificationSpcfwCurrent == "true"
        alertWpcmpdSw = findViewById(R.id.alert_wpcmpd_switch)
        alertWpcmpdSw.setOnCheckedChangeListener(this)
        alertWpcmpdSw.isChecked = alertNotificationWpcmpdCurrent == "true"
        hideNONUSNotifs()
    }

    @SuppressLint("StaticFieldLeak")
    private inner class SaveLoc : AsyncTask<String, String, String>() {

        internal var toastStr = ""

        override fun doInBackground(vararg params: String): String {
            if (params[0] == "osm")
                toastStr = Location.locationSave(contextg, params[1], params[2], params[3], params[4])
            return "Executed"
        }

        override fun onPostExecute(result: String) {
            showMessage(toastStr)
            updateSubTitle()
        }
    }

    @SuppressLint("StaticFieldLeak")
    private inner class AddressSearch : AsyncTask<String, String, String>() {

        internal var xyStr = listOf<String>()

        override fun doInBackground(vararg params: String): String {
            if (params[0] == "osm") xyStr = UtilityLocation.getXYFromAddressOSM(params[1])
            return "Executed"
        }

        override fun onPostExecute(result: String) {
            locXEt.setText(xyStr[0])
            locYEt.setText(xyStr[1])
        }
    }

    override fun onStop() {
        super.onStop()
        val restartNotif = Utility.readPref(this, "RESTART_NOTIF", "false")
        if (restartNotif == "true") {
            UtilityWXJobService.startService(this)
            Utility.writePref(this, "RESTART_NOTIF", "false")
        }
        Location.refreshLocationData(this)
    }

    override fun onCreateOptionsMenu(menu: Menu): Boolean {
        val inflater = menuInflater
        inflater.inflate(R.menu.settings_location_generic, menu)
        val searchView = menu.findItem(R.id.ab_search).actionView as ArrayAdapterSearchView
        if (!UtilityCitiesCA.cityInit) UtilityCitiesCA.loadCitiesArray()
        val tmpArr = UtilityCities.cities.toList() + UtilityCitiesCA.CITIES_CA.toList()
        cityAa = ArrayAdapter(this, android.R.layout.simple_spinner_dropdown_item, tmpArr)
        cityAa.setDropDownViewResource(MyApplication.spinnerLayout)
        searchView.setAdapter(cityAa)
        searchView.setOnItemClickListener(AdapterView.OnItemClickListener { _, _, position, _ ->
            var k = 0
            for (y in tmpArr.indices) {
                if (cityAa.getItem(position) == tmpArr[y]) {
                    k = y
                    break
                }
            }
            if (k < UtilityCities.cities.size) {
                searchView.setText(cityAa.getItem(position)!!)
                locLabelEt.setText(cityAa.getItem(position))
                locXEt.setText(UtilityCities.lat[k].toString())
                locYEt.setText("-" + UtilityCities.lon[k].toString())
                val searchViewLocal = menuLocal!!.findItem(R.id.ab_search).actionView as SearchView
                searchViewLocal.onActionViewCollapsed()
                searchViewLocal.isIconified = true
                val xStr = locXEt.text.toString()
                val yStr = locYEt.text.toString()
                val labelStr = locLabelEt.text.toString()
                SaveLoc().executeOnExecutor(AsyncTask.THREAD_POOL_EXECUTOR, "osm", locNum, xStr, yStr, labelStr)
            } else {
                k -= UtilityCities.cities.size
                var prov = MyApplication.comma.split(cityAa.getItem(position))[1]
                prov = prov.replace(" ", "")
                // X: CANADA:ON:46.5
                // Y: CODE:-84.
                searchView.setText(cityAa.getItem(position)!!) // removed .toString() on this and below
                locLabelEt.setText(cityAa.getItem(position))
                locXEt.setText("CANADA:" + prov + ":" + UtilityCitiesCA.LAT_CA[k].toString())
                locYEt.setText(UtilityCitiesCA.code[k] + ":-" + UtilityCitiesCA.LON_CA[k].toString())
                val searchViewLocal = menuLocal!!.findItem(R.id.ab_search).actionView as SearchView
                searchViewLocal.onActionViewCollapsed()
                searchViewLocal.isIconified = true
                val xStr = locXEt.text.toString()
                val yStr = locYEt.text.toString()
                val labelStr = locLabelEt.text.toString()
                showMessage("Saving location: $labelStr")
                SaveLoc().executeOnExecutor(AsyncTask.THREAD_POOL_EXECUTOR, "osm", locNum, xStr, yStr, labelStr)
            }
        })

        searchView.setOnQueryTextListener(object : OnQueryTextListener {

            override fun onQueryTextChange(newText: String): Boolean { return false }

            override fun onQueryTextSubmit(query: String): Boolean {
                locLabelEt = findViewById(R.id.loc_label_text)
                locLabelEt.setText(query)
                val addrSend = query.replace(" ", "+")
                AddressSearch().executeOnExecutor(AsyncTask.THREAD_POOL_EXECUTOR, "osm", addrSend)
                val searchViewLocal = menuLocal!!.findItem(R.id.ab_search).actionView as SearchView
                searchViewLocal.onActionViewCollapsed()
                return false
            }
        })
        menuLocal = menu
        // set sv text black if white theme
        // thanks David_E http://stackoverflow.com/questions/27156680/change-textcolor-in-searchview-using-android-toolbar
        if (UIPreferences.themeInt == R.style.MyCustomTheme_white_NOAB) changeSearchViewTextColor(searchView)
        // the SearchView's AutoCompleteTextView drop down. For some reason this wasn't working in styles.xml
        val autoCompleteTextView:SearchView.SearchAutoComplete = searchView.findViewById(R.id.search_src_text)
        if (UIPreferences.themeInt == R.style.MyCustomTheme_white_NOAB)
            autoCompleteTextView.setDropDownBackgroundResource(R.drawable.dr_white)
        else
            autoCompleteTextView.setDropDownBackgroundResource(R.drawable.dr_dark_blue)
        return true
    }

    override fun onMenuItemClick(item: MenuItem): Boolean {
        when (item.itemId) {
            R.id.action_delete -> {
                Location.deleteLocation(this, locNum)
                afterDelete()
                showMessage("Deleted location: $locNum ($locLabelCurrent)")
                UtilityWXJobService.startService(this)
                var locNumIntCurrent = Location.numLocations
                locNumIntCurrent++
                locNumToSaveStr = locNumIntCurrent.toString()
                locNum = locNumToSaveStr
                locLabelCurrent = "Location $locNumToSaveStr"
                //
                // needed to prevent old location(deleted) data from showing up when adding new
                //
                locXStr = ""
                locYStr = ""
                locXEt.setText(locXStr)
                locYEt.setText(locYStr)
                locLabelEt.setText(locLabelCurrent)
                title = locLabelCurrent
                afterDelete()
                finish()
            }
            R.id.action_map -> {
                val xStr = locXEt.text.toString()
                val yStr = locYEt.text.toString()
                if (xStr.isNotEmpty() && yStr.isNotEmpty()) {
                    if (Location.us(xStr)) {
                        ObjectIntent(this, WebscreenAB::class.java, WebscreenAB.URL, arrayOf(UtilityMap.genMapURL(xStr, yStr, "9"), "wX"))
                    } else {
                        val addressForMap = locLabelEt.text.toString()
                        ObjectIntent(this, WebscreenAB::class.java, WebscreenAB.URL, arrayOf(UtilityMap.genMapURLFromStreetAddress(addressForMap), "wX"))
                    }
                }
            }
            R.id.action_ca -> ObjectIntent(this, SettingsLocationCanadaActivity::class.java)
            R.id.action_ab -> openCAMap("ab")
            R.id.action_bc -> openCAMap("bc")
            R.id.action_mb -> openCAMap("mb")
            R.id.action_nb -> openCAMap("nb")
            R.id.action_nl -> openCAMap("nl")
            R.id.action_ns -> openCAMap("ns")
            R.id.action_nt -> openCAMap("nt")
            R.id.action_nu -> openCAMap("nu")
            R.id.action_on -> openCAMap("on")
            R.id.action_pe -> openCAMap("pe")
            R.id.action_qc -> openCAMap("qc")
            R.id.action_sk -> openCAMap("sk")
            R.id.action_yt -> openCAMap("yt")
            R.id.action_vr -> {
                val i = Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH)
                i.putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, "en-US")
                try {
                    startActivityForResult(i, REQUEST_OK)
                } catch (e: Exception) {
                    Toast.makeText(this, "Error initializing speech to text engine.", Toast.LENGTH_LONG).show()
                }
            }
            R.id.action_help -> showHelpText(resources.getString(R.string.activity_settings_generic_help))
            else -> return super.onOptionsItemSelected(item)
        }
        return true
    }

    override fun onOptionsItemSelected(item: MenuItem): Boolean {
        when (item.itemId) {
            R.id.action_locate -> {
                if (Build.VERSION.SDK_INT < 23) {
                    val xy = UtilityLocation.getGPS(this)
                    locXEt.setText(xy[0].toString())
                    locYEt.setText(xy[1].toString())
                } else {
                    if (ContextCompat.checkSelfPermission(this, android.Manifest.permission.ACCESS_FINE_LOCATION) == PackageManager.PERMISSION_GRANTED) {
                        val xy = UtilityLocation.getGPS(this)
                        locXEt.setText(xy[0].toString())
                        locYEt.setText(xy[1].toString())
                    } else {
                        // The ACCESS_FINE_LOCATION is denied, then I request it and manage the result in
                        // onRequestPermissionsResult() using the constant MY_PERMISSION_ACCESS_FINE_LOCATION
                        if (ContextCompat.checkSelfPermission(this, Manifest.permission.ACCESS_FINE_LOCATION) != PackageManager.PERMISSION_GRANTED) {
                            ActivityCompat.requestPermissions(this, arrayOf(Manifest.permission.ACCESS_FINE_LOCATION), MY_PERMISSION_ACCESS_FINE_LOCATION)
                        }
                    }
                }
                return true
            }
            else -> return super.onOptionsItemSelected(item)
        }
    }

    private val MY_PERMISSION_ACCESS_FINE_LOCATION = 5001

    override fun onRequestPermissionsResult(requestCode: Int, permissions: Array<String>, grantResults: IntArray) {
        when (requestCode) {MY_PERMISSION_ACCESS_FINE_LOCATION -> if (grantResults.isNotEmpty() && grantResults[0] == PackageManager.PERMISSION_GRANTED) {
                val xy = UtilityLocation.getGPS(this)
                locXEt.setText(xy[0].toString())
                locYEt.setText(xy[1].toString())
            }
        }
    }

    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (requestCode == REQUEST_OK && resultCode == Activity.RESULT_OK) {
            val thingsYouSaid = data!!.getStringArrayListExtra(RecognizerIntent.EXTRA_RESULTS)
            showMessage(thingsYouSaid[0])
            val addrStrTmp = thingsYouSaid[0]
            locLabelEt.setText(addrStrTmp)
            val addrSend = addrStrTmp.replace(" ", "+")
            AddressSearchAndSave().executeOnExecutor(AsyncTask.THREAD_POOL_EXECUTOR, "osm", locNum, addrSend, addrStrTmp)
        }
    }

    @SuppressLint("StaticFieldLeak")
    private inner class AddressSearchAndSave : AsyncTask<String, String, String>() {

        internal var xyStr = listOf<String>()
        internal var toastStr = ""
        internal var goodLocation = false

        override fun doInBackground(vararg params: String): String {
            if (params[0] == "osm") {
                xyStr = UtilityLocation.getXYFromAddressOSM(params[2])
                if (xyStr.size > 1) {
                    toastStr = Location.locationSave(contextg, params[1], xyStr[0], xyStr[1], params[3])
                    goodLocation = true
                }
            }
            return "Executed"
        }

        override fun onPostExecute(result: String) {
            locXEt.setText(xyStr[0])
            locYEt.setText(xyStr[1])
            if (goodLocation) {
                showMessage(toastStr)
                Utility.writePref(contextg, "CURRENT_LOC_FRAGMENT", locNum)
                Location.currentLocationStr = locNum
            }
            finish()
        }
    }

    @SuppressLint("StaticFieldLeak")
    private inner class GPSAndSave : AsyncTask<String, String, String>() {

        internal var xyStr = listOf<String>()
        internal var toastStr = ""
        internal var xy = doubleArrayOf(0.0,0.0)
        internal var goodLocation = false

        override fun doInBackground(vararg params: String): String {
            xyStr = listOf(xy[0].toString(), xy[1].toString())
            if (xyStr.size > 1) {
                toastStr = Location.locationSave(contextg, params[1], xyStr[0], xyStr[1], params[2])
                goodLocation = true
            }
            return "Executed"
        }

        override fun onPostExecute(result: String) {
            if (goodLocation) {
                showMessage(toastStr)
                Utility.writePref(contextg,"ALERT" + locNum + "_NOTIFICATION", "true")
                Utility.writePref(contextg,"CURRENT_LOC_FRAGMENT", locNum)
                Location.currentLocationStr = locNum
            }
            finish()
        }

        override fun onPreExecute() {
            xy = UtilityLocation.getGPS(contextg)
            locXEt.setText(xy[0].toString())
            locYEt.setText(xy[1].toString())
        }
    }

    private fun hideNotifsCA() {
        alertMcdSw.visibility = View.GONE
        alertSwoSw.visibility = View.GONE
        alertSpcfwSw.visibility = View.GONE
        alertWpcmpdSw.visibility = View.GONE
        listOf(R.id.alert_mcd_switch_text,R.id.alert_swo_switch_text,R.id.alert_spcfw_switch_text,R.id.alert_wpcmpd_switch_text).forEach {
            val tv:TextView = findViewById(it)
            tv.visibility = View.GONE
        }
        cv7.setVisibility(View.GONE)
        cv8.setVisibility(View.GONE)
        cv9.setVisibility(View.GONE)
        cv10.setVisibility(View.GONE)
    }

    private fun hideNONUSNotifs() {
        val label = locXEt.text.toString()
        if (label.contains("CANADA")) hideNotifsCA()
    }

    private fun updateSubTitle() {
        val subStr = Utility.readPref(this, "NWS$locNum", "") + " " + Utility.readPref(this, "RID$locNum", "")
        if (subStr != "   " && updateTitle) toolbar.subtitle = subStr
    }

    private fun changeSearchViewTextColor(view: View?) {
        if (view != null) {
            if (view is TextView) {
                view.setTextColor(Color.WHITE)
            } else if (view is ViewGroup) {
                for (i in 0 until view.childCount) { changeSearchViewTextColor(view.getChildAt(i)) }
            }
        }
    }

    private fun fabSaveLocation() {
        val xStr = locXEt.text.toString()
        val yStr = locYEt.text.toString()
        val labelStr = locLabelEt.text.toString()
        SaveLoc().executeOnExecutor(AsyncTask.THREAD_POOL_EXECUTOR, "osm", locNum, xStr, yStr, labelStr)
    }

    private fun openCAMap(s: String) { ObjectIntent(this, SettingsLocationCanadaMapActivity::class.java, SettingsLocationCanadaMapActivity.URL, arrayOf(s)) }

    private fun showMessage(string: String){ UtilityUI.makeSnackBar(rl ,string) }
}
