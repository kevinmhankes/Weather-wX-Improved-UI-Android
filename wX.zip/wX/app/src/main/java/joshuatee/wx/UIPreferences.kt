/*

    Copyright 2013, 2014, 2015, 2016, 2017, 2018  joshua.tee@gmail.com

    This file is part of wX.

    wX is free software: you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation, either version 3 of the License, or
    (at your option) any later version.

    wX is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with wX.  If not, see <http://www.gnu.org/licenses/>.

 */

package joshuatee.wx

import android.content.Context
import android.graphics.Color
import android.support.v4.content.ContextCompat

import joshuatee.wx.util.Utility

object UIPreferences {

    var refreshLocMin = 0
    var translateText = false
    var nwsTextRemovelinebreaks = false
    var recordScreenShare = false
    var prefPreventAccidentalExit = false
    var fabInModels = false
    var backgroundColor = Color.WHITE
    var colorNotif = 0
    var colorBlack = 0
    var colorOffwhiteToolbar = 0
    var dualpaneRadarIcon = false
    var homescreenTextLength = 0
    var mediaControlNotif = false
    var radarToolbarTransparent = false
    var radarImmersiveMode = false
    var tilesPerRow = 3
    var themeStr = ""
    var themeInt = 0
    var smallTextTheme = 0
    var textHighlightColor = 0
    var highlightColorStr = ""

    fun initPreferences(context: Context) {
        homescreenTextLength = Utility.readPref(context, "HOMESCREEN_TEXT_LENGTH_PREF", 500)
        refreshLocMin = Utility.readPref(context, "REFRESH_LOC_MIN", 10)
        translateText = Utility.readPref(context, "TRANSLATE_TEXT", "").startsWith("t")
        nwsTextRemovelinebreaks = Utility.readPref(context, "NWS_TEXT_REMOVELINEBREAKS", "true").startsWith("t")
        recordScreenShare = Utility.readPref(context, "RECORD_SCREEN_SHARE", "true").startsWith("t")
        prefPreventAccidentalExit = Utility.readPref(context, "PREF_PREVENT_ACCIDENTAL_EXIT", "true").startsWith("t")
        dualpaneRadarIcon = Utility.readPref(context, "DUALPANE_RADAR_ICON", "false").startsWith("t")
        fabInModels = Utility.readPref(context, "FAB_IN_MODELS", "true").startsWith("t")
        colorNotif = ContextCompat.getColor(context, R.color.primary_dark_blue)
        colorBlack = ContextCompat.getColor(context, R.color.black)
        colorOffwhiteToolbar = ContextCompat.getColor(context, R.color.offwhite_toolbar)
        mediaControlNotif = Utility.readPref(context, "MEDIA_CONTROL_NOTIF", "").startsWith("t")
        radarToolbarTransparent = Utility.readPref(context, "RADAR_TOOLBAR_TRANSPARENT", "false").startsWith("t")
        radarImmersiveMode = Utility.readPref(context, "RADAR_IMMERSIVE_MODE", "false").startsWith("t")
        tilesPerRow = Utility.readPref(context, "UI_TILES_PER_ROW", tilesPerRow)
        themeStr = Utility.readPref(context, "THEME_BLUE", "blue")
        themeInt = Utility.theme(themeStr)
        if (themeInt == R.style.MyCustomTheme_white_NOAB) {
            smallTextTheme = android.R.style.TextAppearance_Small_Inverse
            textHighlightColor = Color.BLUE
            backgroundColor = Color.BLACK
            highlightColorStr = "blue"
        } else {
            smallTextTheme = android.R.style.TextAppearance_Small
            textHighlightColor = Color.YELLOW
            backgroundColor = Color.WHITE
            highlightColorStr = "yellow"
        }
    }
}

