package joshuatee.wx.util

class Group(val string: String) {
    val children = mutableListOf<String>()
} 