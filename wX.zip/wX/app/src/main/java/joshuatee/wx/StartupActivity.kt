package joshuatee.wx

import android.os.Bundle
import android.app.Activity

import joshuatee.wx.notifications.UtilityNotification
import joshuatee.wx.notifications.UtilityWXJobService
import joshuatee.wx.objects.ObjectIntent
import joshuatee.wx.radar.WXGLRadarActivity
import joshuatee.wx.settings.Location
import joshuatee.wx.settings.UtilityPref
import joshuatee.wx.settings.UtilityPref2
import joshuatee.wx.settings.UtilityPref3
import joshuatee.wx.settings.UtilityPref4
import joshuatee.wx.util.Utility
import android.content.pm.ShortcutManager
import android.app.PendingIntent
import android.content.pm.ShortcutInfo

class StartupActivity : Activity() {

    // This activity is the first activity started when the app starts.
    // It's job is to initialize preferences if not done previously,
    // display the splash screen, start the service that handles notifications,
    // and display the version in the title.
    //

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)


        // https://developer.android.com/guide/topics/ui/shortcuts
        // Pinned shortcuts in API 26 8.0
     /*   if (android.os.Build.VERSION.SDK_INT > 25) {
            val mShortcutManager = getSystemService(ShortcutManager::class.java)

            if (mShortcutManager.isRequestPinShortcutSupported) {
                // Assumes there's already a shortcut with the ID "my-shortcut".
                // The shortcut must be enabled.

                listOf("Radar", "SPC Mesoanalysis", "NCEP Models", "SPC HREF", "NHC").forEach {
                    val pinShortcutInfo = ShortcutInfo.Builder(this, it).build()
                    // Create the PendingIntent object only if your app needs to be notified
                    // that the user allowed the shortcut to be pinned. Note that, if the
                    // pinning operation fails, your app isn't notified. We assume here that the
                    // app has implemented a method called createShortcutResultIntent() that
                    // returns a broadcast intent.
                    val pinnedShortcutCallbackIntent = mShortcutManager.createShortcutResultIntent(pinShortcutInfo)
                    // Configure the intent so that your app's broadcast receiver gets
                    // the callback successfully.
                    val successCallback = PendingIntent.getBroadcast(this, 0, pinnedShortcutCallbackIntent, 0)
                    mShortcutManager.requestPinShortcut(pinShortcutInfo, successCallback.intentSender)
                }
            }
        }*/


        // FIXME
        if (Utility.readPrefWithNull(this, "NWS_UNR_X", null) == null) {
            UtilityPref.prefInitStateCode(this)
            UtilityPref.prefInitStateCodeLookup(this)
            UtilityPref.prefInitNWSXY(this)
            UtilityPref.prefInitRIDXY(this)
            UtilityPref.prefInitRIDXY2(this)
            UtilityPref.prefInitNWSLoc(this)
            UtilityPref2.prefInitSetDefaults(this)
            UtilityPref3.prefInitRIDLoc(this)
            UtilityPref.prefInitBig(this)
            UtilityPref.prefInitTwitterCA(this)
            UtilityPref4.prefInitSoundingSites(this)
        }
        if (Utility.readPrefWithNull(this,"SND_AOT_X", null) == null) UtilityPref4.prefInitSoundingSitesLoc(this)
        MyApplication.initPreferences(this)
        Location.refreshLocationData(this)
        UtilityWXJobService.startService(this)
        if (UIPreferences.mediaControlNotif) { UtilityNotification.createMediaControlNotif(applicationContext, "") }
        if (Utility.readPref(this, "LAUNCH_TO_RADAR", "false") == "false") {
            ObjectIntent(this, WX::class.java)
        } else {
            val nws1Current = Location.wfo
            val nws1StateCurrent = Utility.readPref(this, "NWS_LOCATION_$nws1Current", "").split(",")[0]
            val rid1 = Location.getRid(this, Location.currentLocationStr)
            ObjectIntent(this, WXGLRadarActivity::class.java, WXGLRadarActivity.RID, arrayOf(rid1, nws1StateCurrent))
        }
        finish()
    }
}
